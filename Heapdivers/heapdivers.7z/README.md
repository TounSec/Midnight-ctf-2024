# Information

- *Title:* Heapdivers
- *Category:* Pwn
- *Difficulty level:* Medium
- *Vulnerability exposed:* Heap based, Use After Free (UAF)
- *Description:* The helldivers are ready to die to repel the Terminid and Automaton invaders, to spread democracy and preserve the serenity of the super-Earth - such is their duty. On a mission to the planet Hellmire, you'll have to choose your stratagems carefully if you want to successfully complete this mission and plant the flag that will mark the conquest of this planet and the end of the Terminid invasion. Good luck helldivers! For democracy !
